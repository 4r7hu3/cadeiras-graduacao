x = int(input("Digite um inteiro positivo: "))
cont = 0;

while(x<=0):
  x = int(input("\nERRO! Digite novamente: "))
  
for i in range(1, x+1):
  if(x%i==0):
    cont+=1

if(cont==2):
  print("\n{} é número primo".format(x))
else:
  print("\n{} não é número primo".format(x))