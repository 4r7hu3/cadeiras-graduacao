opt = ("PEDRA", "PAPEL", "TESOURA")

while True:

  print("\n1. PEDRA")
  print("2. PAPEL")
  print("3. TESOURA")

  jogada = int(input("\nEscolha uma opção: "))
    
  if(jogada == 1):
    print("\nMáquina: TESOURA")
    print("Jogador: {}".format(opt[0]))
    print("Vencedor: Jogador")
  elif(jogada == 2):
    print("\nMáquina: PEDRA")
    print("Jogador: {}".format(opt[1]))
    print("Vencedor: Jogador")
  elif(jogada == 3):
    print("\nMáquina: PAPEL")
    print("Jogador: {}".format(opt[2]))
    print("Vencedor: Jogador")
  else:
      print("\nJogo encerrado!\n")
      break
