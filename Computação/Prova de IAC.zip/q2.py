matrix = [[0,0], [0,0]]

for i in range(0, 2):
  for j in range(0, 2):
    matrix[i][j] = int(input("Digite um real: "))

print("-----------------")

for i in range(0, 2):
  for j in range(0,2):
    print(f'[{matrix[i][j]}]', end='')
  print()

print("-----------------")

numLinhas = len(matrix)
numColunas = len(matrix[0])
r = []

for l in range(numLinhas):
  r.append([])
  for c in range(numColunas):
    r[l].append(0)
    for m in range(numColunas):
      r[l][c] += matrix[l][m] * matrix[m][c]

print("Produto: \n")

for i in range(0,2):
  for j in range(0,2):
    print(f'[{r[i][j]}]', end='')
  print()