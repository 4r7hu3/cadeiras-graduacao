x = int(input("Digite um número inteiro de 3 dígitos: "))

x = str(x)
t = '0' in x

if len(x) == 3 and t == False:
	v = list(x)
	v.reverse();
	v = "".join(v)
	print("Espelho:",v)
else:
	print("\nDigite um inteiro de 3 dígitos diferentes de 0.")