num = int(input("Digite um número inteiro positivo: "))

if num%35 == 0:
	print("\n{} é divisível por 35".format(num))
	if num%10 == 0:
		print("{} é divisível por 10".format(num))
		print("{} é divisível por 2".format(num))
	else:
		print("{} não é divisível por 10".format(num))
		print("{} não é divisível por 2".format(num))
	print("{} é divisível por 7".format(num))
	print("{} é divisível por 5".format(num))
elif num%10 == 0:
	print("\n{} não é divisível por 35".format(num))
	print("{} é divisível por 10".format(num))
	print("{} não é divisível por 7".format(num))
	print("{} é divisível por 5".format(num))
	print("{} é divisível por 2".format(num))
elif num%7 == 0:
	print("\n{} não é divisível por 35".format(num))
	print("{} não é divisível por 10".format(num))
	print("{} é divisível por 7".format(num))
	print("{} não é divisível por 5".format(num))
	if num%2 == 0:
		print("{} é divisível por 2".format(num))
	else:
		print("{} não é divisível por 2".format(num))
elif num%5 == 0:
	print("\n{} não é divisível por 35".format(num))
	print("{} não é divisível por 10".format(num))
	print("{} não é divisível por 7".format(num))
	print("{} é divisível por 5".format(num))
	print("{} não é divisível por 2".format(num))
else:
	print("\n{} não é divisível por 35".format(num))
	print("{} não é divisível por 10".format(num))
	print("{} não é divisível por 7".format(num))
	print("{} não é divisível por 5".format(num))
	print("{} é divisível por 2".format(num))
