#primeira forma:

word = input("Digite uma palavra: ")
word = word.lower();

vet = list(word)

vet.reverse();

nword = "".join(vet)

if len(word) == 5:
	if nword == word:
		print("\n\'{}' é um palíndromo.".format(word))
	else:
		print("\n\'{}' não é um palíndromo.".format(word))
else: 
	print("\nDigite uma palavra de 5 letras.")


#segunda forma: 
'''
word = input("Digite uma palavra: ")
word = word.lower()

inv = word[::-1]

if len(word) == 5:
	if word == inv:
		print("\n\'{}' é um palíndromo.".format(word))
	else:
		print("\n\'{}' não é um palíndromo.".format(word))
else:
	print("\nDigite uma palavra de 5 letras.")
'''