def tupla(l):
	n = len(l)
	maior = l[0][0]
	t = l[0]
	

	for i in range(n):
		if l[i][0]>maior:
			maior = l[i][0]
			t = l[i]
	
	return t


l = [(3, 5, 2), (6, 0), (1, 2, 3, 4, 5, 6, 7), (4, 7, 3, 700 )]
m = [(10, 9, 8, 7), (3, 9), (9,3), (25, 16), (16, 25)]

x = tupla(l)
y = tupla(m)

print(x)
print(y)