#Em uma função, o 'return' é o método padrão que vai fazer com que a mesma retorne um parâmetro quando for chamada. Quando não há o 'return' na função, ou quando a expressão dentro do escopo dela não é satisfeita, é retornado automaticamente o tipo 'None'.

#É o que acontece na questão 3, já que não há nenhum retorno de valor. Porém, só é possível de ver esse valor None dentro do shell, quando a função é chamada e passada para dentro de alguma variavél.

#Acho importante dizer também que funções que retornam o tipo 'None' não são erros ou excessões.