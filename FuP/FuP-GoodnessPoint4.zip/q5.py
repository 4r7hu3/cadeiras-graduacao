#devolveria os valores numa forma de tupla ou lista:

def minEMax(l):
	maior = l[0]

	for i in l:
		if i>maior:
			maior = i
	
	menor = l[0]

	for i in l:
		if i<menor:
			menor = i
		
	return [menor, maior]


lista = [15, 24, 56, 45, 2, 8]
extremos = minEMax(lista)

print('Mínimo: {0} // Máximo: {1}'.format(extremos[0],extremos[1]))