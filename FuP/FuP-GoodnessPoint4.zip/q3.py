def maiorValor(l):
	aux = l[0]
	
	for i in l:
		if i>aux:
			aux = i
			
	print('Maior valor: {}'.format(aux))


l = [100, 20, 17, 3, 99, 101, 25, 36, 9,]
maiorValor(l)

# x = maiorValor(l)
# print(x)