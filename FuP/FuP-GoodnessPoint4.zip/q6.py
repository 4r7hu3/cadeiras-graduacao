def listaZ(v, w):
	z = []
	vsize = len(v)
	
	for i in range(vsize):
		maximo = v[i]
		if w[i]>maximo:
			maximo = w[i]
			z.append(w[i])
		else:
			z.append(v[i])

	return z


v = [45, 10, 3, 13, 50]
w = [44, 11, 5, 12, 50]

l = listaZ(v, w)
print(l)