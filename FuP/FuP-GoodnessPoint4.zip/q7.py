# def subs(l):
# 	for i in l:
# 		l.remove(i)
# 		l.insert(i-1,0)
			
# 	return l


# lista = [1, 2, 3, 4, 5, 6, 7, 8 , 9, 10]
# subs(lista)
# print(lista)


def subs(l):
	t = len(l)
	l.clear()
	
	for i in range(t):
		l.append(0)
	
	return l

lista = [1, 2, 3, 4, 5, 6, 7, 8 , 9, 10]
subs(lista)
print(lista)