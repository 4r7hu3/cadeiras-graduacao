def maiorValor(l):
	aux = l[0]
	
	for i in l:
		if i>aux:
			aux = i
				
	return aux


l = [22, 44, 2, 11, 43, 5, 14, 27, 33]

maior = maiorValor(l)
print('Maior valor da lista: {}'.format(maior))