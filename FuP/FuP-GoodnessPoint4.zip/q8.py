def concString(l):
	c = [' ', ',', '.', ':', '/', '?', '!', '@', '#', '$', '*', '+', '-']
	conc = ''
	conc2 = ''

	for i in l:
		conc+=i

	vet = list(conc)

	for i in c:
		for j in vet:
			if i == j:
				vet.remove(i)

	for i in vet:
		conc2+=i

	return conc2


s = ['O rato', 'roeu', 'a roupa', 'do rei', 'de', 'Roma!']

x = concString(s)
print(x)

