
arq = open('activity_2338606858.tcx', 'r')

for x in arq.readlines():
    
    if x.startswith('            <DistanceMeters>'):
        x = x[len('            <DistanceMeters>'):]
        L = x.split('</DistanceMeters>')
        print(L[0])

